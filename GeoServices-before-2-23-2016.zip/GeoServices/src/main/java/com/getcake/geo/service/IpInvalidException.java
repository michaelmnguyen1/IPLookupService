package com.getcake.geo.service;

public class IpInvalidException extends Throwable {

	public IpInvalidException (String msg) {
		super (msg);
	}
}
