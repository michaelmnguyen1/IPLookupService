package com.getcake.geo.service;

public class IpNotFoundException extends Throwable {

	public IpNotFoundException (String msg) {
		super (msg);
	}
}
